//author: Duck Nguyen
//CS145 Assignment 6 - 11/12/16
//CardArrayList.java
//CardArrayList maintain a list of cards

import java.security.InvalidParameterException;
import java.util.*;

public class CardArrayList{
	private int size;
	private Card[] hand;
	private Random rand = new Random();
	
	public CardArrayList(){
		this(10);
	}//end
	
	public CardArrayList(int x){
		if (x < 1) 
			throw new InvalidParameterException(); 
	      
	    hand = new Card[x]; 
	    size = 0;
	}//end
	   
	public String toString(){
		//String values = "";
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < size; i++) {
		    if(hand[i] != null) sb.append(hand[i].toString());
		    if (i != size-1) sb.append(",");
		} 
		
		return ("[0: " + sb.toString() + " :" + size +"]"); 
	}//end
	   
	public int size(){
		return size; 
	}//end
	   
	public void add(Card x){
		if (size == hand.length){
			// resize it
			Card[] temp = new Card[hand.length+10];
			for (int i = 0; i < hand.length; i++){
				temp[i] = hand[i];
			}
			hand = temp;
		}
		
		hand[size] = x;
		size++;
	}//end
	
	public Card remove(){
		return hand[size--];
	}//end
	
	public Card get(int x){
		if(x<0 || x >=size) throw new IndexOutOfBoundsException();
		return hand[x];
	}//end
	
	public int indexOf(Card x){
		for(int i = 0; i < size; i++){
			// debugging... should probably have put the indexOf() test before the boost() test...
			//System.out.print("\n\tthis:" + hand[i].toString() + " x: " + x.toString());
			if (hand[i].compareTo(x) == 0){
				return i;
			}
		}
		return -1;
	}//end
	
	public void add(int l, Card x){
		for(int i = size; i >= l +1; i--){
			hand[i] = hand[i-1];
		}
		hand[l] = x;
		size++;
	}//end
	
	public Card remove(int j){
		Card temp = hand[j];
		for(int i = j; i < size-1; i++){
			hand[i] = hand[i+1];
		}
		size--;
		return temp;
	}//end
	
	public void sort(){
		Card[] trimmed = new Card[size];
		for (int i = 0; i < size; i++){
			trimmed[i] = hand[i];
		}
		Arrays.sort(trimmed);
		//Card[] temp = new Card[hand.length];
		Card temp;
		for (int i = 0; i < size/2; i++){
			temp = trimmed[size-1-i];
			trimmed[size-1-i] = trimmed[i];
			trimmed[i] = temp;
		}		
		
		for (int i = 0; i < size; i++){
			hand[i] = trimmed[i];
		}
	}//end
	
	public void shuffle(){
		for (int i = size - 1; i > 0; i--){
	      int index = rand.nextInt(i + 1);
	      // Simple swap
	      Card a = hand[index];
	      hand[index] = hand[i];
	      hand[i] = a;
	    }
	}//end 
	
	private boolean isRoom(){
		return size<hand.length; 
	}//end
	
	private void swap(int a, int b){
		Card temp = hand[a];
		hand[a] = hand[b];
		hand[b] = temp;
	}//end
	
	public void clear(){
		size = 0;
	}//end
}//end class 	
	
//author: Duck Nguyen
//CS145 Assignment 6 - 11/12/16
//Card.java
//Card class contain one particular card 

import java.security.InvalidParameterException;
import java.util.*; 

public class Card implements Comparable<Card>{
   private Random rand = new Random();
   // private final int bound = rand.nextInt(1000) +1; 
   private int power;
   private int toughness;
   
   // *************CONSTRUCTORS****************
   public Card() {
      power = rand.nextInt(1000) +1;
      toughness = rand.nextInt(1000) +1; 
   }//end
   
   public Card(int x) {
	  if(x<1 || x>1000)
		  throw new InvalidParameterException();
	  
	  power = toughness = x;
   }//end
   
   public Card(int p, int t){   
      // if(card.getPower)?
      if (p < 1 || p > 1000 || t < 1 || t > 1000)
         throw new InvalidParameterException(); 
     // create card
     power = p;
     toughness = t; 
   } //end      
   
   public int getPower(){
      return power;
   }//end
   
   public int getToughness(){  
      return toughness;
   }//end
   
   public int getCost(){
      return (int)Math.ceil(Math.sqrt(1.5 * power * 0.9 * toughness));
   }//end
   
   public String toString(){
      return "[" + power + "/" + toughness + "]";
   }//end
   
   @Override
   public int compareTo(Card c) {
	   if (getCost() == c.getCost()){
		   if(getPower() == c.getPower()){
			   return getToughness() - c.getToughness();
		   }
		   else {
			   return getPower() - c.getPower();
		   }
	   }
	   return getCost() - c.getCost();
   }//end 
   
   public void weaken(){
      power*=.9;
      toughness*=.9;
      
   }//end
   
   public void boost(){
      power *= 1.1;
      toughness *= 1.1; 
   }//end


}//end class
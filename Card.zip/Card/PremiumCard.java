//author: Duck Nguyen
//CS145 Assignment 6 - 11/12/16
//PremiumCard.java
//PremiumCard holds a secondary type of card  
public class PremiumCard extends Card {

	public PremiumCard() {
		super();
	}//end

	public PremiumCard(int x) {
		super(x);
	}//end

	public PremiumCard(int p, int t) {
		super(p, t);
	}//end

	public String toString() {
		return "{{" + super.getPower() + "/" + super.getToughness() + "}}";
	}//end
}//end class

//@author: Duck Nguyen, CS 145, Fall 2016
//In class Assignment #4-10/12/16
//isPalindrome.java
//This program check if a string passed is a palindrome or not using recursive programming

import java.util.Scanner;
public class Palindromes{


   public static void main(String[]args){
      Scanner input = new Scanner(System.in);
      System.out.println("enter your word");
      String s = input.nextLine();
      
      if(isPalindrome(s))
         System.out.println(s + " is a palindrome");
      else
         System.out.println(s + " is not a palindrome");
   }//end main 
   
   
   public static boolean isPalindrome(String s){
      //base case
      if (s.length() == 0 || s.length() == 1){
         //System.out.println(s);
         return true;
      }
      
      //recursion, trimming the string 
      if(s.charAt(0) == s.charAt(s.length()-1)){
         //System.out.println(s);
         return isPalindrome(s.substring(1,s.length()-1));
      }
      
      else{
         return false;
      }
   }//end isPalindrome  
   
    
    
   /*minimal version
   public static boolean isPalindrome2(String s){
      if(s.length() <2){
         return true;
      }else{
         //using &&-both argument has to be true, so if one's false -> false
         return s.charAt(0) == s.charAt(s.length()-1) && 
         isPalindrome(s.substring(1, s.length()-1));
      }
   
   } 
   */
        
}
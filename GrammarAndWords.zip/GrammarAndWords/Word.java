//@author: Duck Nguyen, CS 145, Fall 2016
//Programming Assignment #5, 11/01/16
//Word.java
//This program handles a single word, and its canonical form

import java.util.Arrays;

public class Word implements Comparable<Word>{
	String original;
	String canonical;
	
	public Word(String x){
		x = x.toLowerCase();
		original = x;
		
		char[] canonChars = x.toCharArray();
		Arrays.sort(canonChars);
		canonical = new String(canonChars);
	}
   
   //overide compareTo
	public int compareTo(Word o) {
		return canonical.compareTo(o.getForm());
	}
  
	
	public String getWord(){
		return original;
	}
	
	public String getForm(){
		return canonical;
	}
	
	public String toString(){
		return "["+original+"="+canonical+"]";
	}
}

//@author: Duck Nguyen, CS 145, Fall 2016
//Programming Assignment #3, 10/12/16
//HangmanManager.java
//This program manage the state of the Evil Hangman game

import java.util.*;

import static java.lang.Math.pow;

public class HangmanManager {
   private String pattern = "";
   private int max;
   private int length;
   private SortedSet<Character> guessesMade;
   private Set<String> currentWords;
   private Map<String, Set<String>> patternMap;
   private Set<String> words;
   private char[] spots;
   private List<Set<String>> sets;

   public HangmanManager(List<String> dictionary, int length, int max){
      this.max = max;
      this.length = length;


      if( length < 1 || max < 0){
         throw new IllegalArgumentException();

      }//end

      words = new TreeSet<String>();
      guessesMade = new TreeSet<Character>();
      currentWords = new TreeSet<String>(words); //current words =(words)
      patternMap = new TreeMap<String, Set<String>>(); //patternMAP = < pattern, words>
      spots = new char[length];
       sets = new LinkedList<Set<String>>();
      for (int i = 0; i < length; i++){
          pattern += "- "; //add "-" according to length
          spots[i] = '-';
      }

      for (String word : dictionary){
         if (word.length() == length){
            words.add(word); //if length of the word matches a word with the same length it will  be added
         }
      }//end for

   }//end constructor


   public Set<String> words(){
      return words;
   }


   public int guessesLeft(){
      return max - guessesMade.size();
   }


   public SortedSet<Character> guesses(){
      return guessesMade;
   }


   public String pattern(){
      if (words.isEmpty()){
         throw new IllegalArgumentException("Invalid No Words");
      }

       pattern = "";

       for(int i = 0; i < length - 1; i++){
           pattern += spots[i] + " ";
       }
       pattern += spots[length - 1];

      return pattern; //return 
   }//end pattern()


   public int record(char guess){
      if (guessesLeft() < 1 || words.isEmpty()){
         throw new IllegalStateException();  
      }

      if (!words.isEmpty() && guessesMade.contains(guess)) {
         throw new IllegalArgumentException();
      }

      guessesMade.add(guess); //guess
        int nSets = (int)(pow(2, length))+1;
       Set<String>[] sets = new  Set[nSets];
       Set<String> blank = new TreeSet<String>();


       for(int i = 0; i < nSets; i++){
           sets[i] = new TreeSet<String>();
       }


      int occurences = 1;

       for (String word : words) {
           int loc = 0;
           for (int i = 0; i < length; i++) {
               if (word.charAt(i) == guess){
                   loc += pow(2, length-1-i);
               }
           }
           sets[loc].add(word);
       }

             int max = 0;
       for(int i = 1; i < nSets; i++){
           if(sets[i].size() > sets[max].size()){
               max = i;
           }
       }

       if (sets[max].size() <= sets[0].size()) {
           words = sets[0];
           max = -1;
       }
       else
           words = sets[max];

         return generatePattern(occurences, max, guess);
   }//end record

   private Set<String> find(){
      int maxSize = 0;
      Map <String, Integer> patternCount = new TreeMap<String, Integer>();
      
      for (String key : patternMap.keySet()){               //keyset equals word
         patternCount.put(key, patternMap.get(key).size()); //the word's size
         
         if (patternMap.get(key).size() > maxSize){
            maxSize = patternMap.get(key).size();
            pattern = key; 
         } 
         
         else if (patternMap.get(key).size() == maxSize){
            if (key.length() >= pattern.length()){
               pattern = key;
               maxSize = patternMap.get(key).size(); 
            }
         }
      }//end for
      
      //System.out.println("Current pattern: " + pattern);
      return patternMap.get(pattern); 
      
   }//end find()

   private int generatePattern(int n, int max, char guess) {
       if(max != -1) {
           for(int i = 0; i < length; i++){
               int number = 0;
               for(String word: words){
                   if (word.charAt(i) == guess) {
                       number++;
                   }
               }
               if(number == words.size()){
                   spots[i] = guess;
                   n++;
               }
           }
           return n-1;
       }else{
           return 0;
       }
        
   }//end generatePattern


}//end class
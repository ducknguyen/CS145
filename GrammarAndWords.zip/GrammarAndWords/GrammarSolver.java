//@author: Duck Nguyen, CS 145, Fall 2016
//Programming Assignment #4, 10/20/16
//GrammarSolver.java
//This program manipulates the passed grammar set
import java.util.*;

public class GrammarSolver {
	Map<String, String[]> grammarRules;
   
	public GrammarSolver(List<String> rules) {
		if (rules == null || rules.size() == 0) {
			throw new IllegalArgumentException();
		}
      //break apart the rules and store in grammarRules 
		grammarRules = new TreeMap<String, String[]>();
		for (String line : rules) {
         
         //temporarily store the non-terminal [0] 
         //throw exception if same terminal is repeated
			String[] nonTerminal = line.split("::="); 
			if (grammarRules.containsKey(nonTerminal[0])) {
				throw new IllegalArgumentException();
			}
         
         //else, split pipes and put them in grammarRules
			String[] ruleParts = nonTerminal[1].split("[|]");
			grammarRules.put(nonTerminal[0], ruleParts);
		}
	}//end constructor 
	
   
	public boolean contains(String symbol) {
	   if (symbol == null || symbol.length() == 0) {
			throw new IllegalArgumentException();
		}
		return grammarRules.keySet().contains(symbol);
	}//end contains 

	public Set<String> getSymbols() {
		return grammarRules.keySet(); 
	}//end getSymbols 

	public String generate(String symbol) {
      //exception
		if (symbol == null || symbol.length() == 0) {
			throw new IllegalArgumentException();
		}
		
      String phrase = "";
      //base case
		if (!contains(symbol)) {
			return symbol;
		} 
      //recursion call
      //rand for random choices of symbol given, return as string
      else {
			String[] rules = grammarRules.get(symbol);
			Random rand = new Random();
			int randNum = rand.nextInt(rules.length);
			String currentRule = rules[randNum].trim();
			String[] grammarRuleParts = currentRule.split("[ \t]+");
			for (String rule : grammarRuleParts) {
				phrase += generate(rule);
			}
			return phrase;
		}
	}//end generate	
}//end class 
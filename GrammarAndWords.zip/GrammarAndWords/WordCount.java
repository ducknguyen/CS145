/*
author: Duck Nguyen
In Class assignment 3 - 05/10/16
wordCount.java
this program reads through a file and counts how many instances a word repeat, and how many words there are in the file    
*/   

import java.io.*;
import java.util.*;


public class WordCount {
  public static void main(String[] args) throws FileNotFoundException {
    //HashMap for fast reading
    HashMap map = new HashMap();  

    //read file
    Scanner read = new Scanner(new File("DataFile1.txt"));
    while (read.hasNext()) {
      String word = read.next();
      
      if(map.containsKey(word)) {
        //count ++ if word repeats
        map.put(word, new Integer(count.intValue() + 1));
      } else {
        //new word -> add word as key, original count = 1
        map.put(word, new Integer(1));
      }
    }//end while

    //print out the words and occurences 
    ArrayList arraylist = new ArrayList(map.keySet());
    Collections.sort(arraylist);
    
    for (int i = 0; i < arraylist.size(); i++) {
      String key = (String)arraylist.get(i);
      Integer count = (Integer)map.get(key);
      System.out.println("Word: " + key + "; Occurence: " + count);
    }//emd

  }//end main
}//end class 
//author: Duck Nguyen
//CS145 Assignment 7 - 11/27/16
//QuestionNode.java
//This program constrols the nodes being created.

public class QuestionNode{
	private String text;
	private QuestionNode parent;
	private QuestionNode yes;
	private QuestionNode no;
	
	public QuestionNode(QuestionNode parent, String txt, QuestionNode y, QuestionNode n){
		this.parent = parent;
		this.text = txt;
		this.yes = y;
		this.no = n;
	}
	
	public QuestionNode(String txt){
		this.parent = null;
		this.text = txt;
		this.yes = null;
		this.no = null;
	}
	
	public boolean isAnswer(){
		return yes==null || no==null;
	}
	
	public QuestionNode getParent(){
		return parent;
	}
	
	public void setParent(QuestionNode parent){
		this.parent = parent;
	}

	public String getText(){
		return text;
	}
	
	public void setText(String txt){
		this.text = txt;
	}

	public QuestionNode getYes(){
		return yes;
	}

	public void setYes(QuestionNode yes){
		this.yes = yes;
	}

	public QuestionNode getNo(){
		return no;
	}

	public void setNo(QuestionNode no){
		this.no = no;
	}
}//end class 

//author: Duck Nguyen
//CS145 Assignment 7 - 11/27/16
//QuestionTree.java
//This program simulates the question tree. 

import java.util.*;
import java.io.*;

public class QuestionTree{

	UserInterface my;
	QuestionNode root;
	int gamesPlayed;
	int gamesWon;
   
   //constructor
	public QuestionTree (UserInterface ui){
		if (ui == null)
			throw new IllegalArgumentException();
		my = ui;
		root = new QuestionNode("computer");
		gamesPlayed = 0;
		gamesWon = 0;
	}//end

	public void play(){
		//my.println("Play Game here");
		ask(root);
		gamesPlayed++;
	}//end

	public void save(PrintStream output){
		if (output == null)
			throw new IllegalArgumentException();
		//my.println("Save the current tree here");
		saveNext(output, root);
	}//end
	
	private void saveNext(PrintStream output, QuestionNode current){
		if (current.isAnswer())
			output.print("A:");
		else
			output.print("Q:");
		output.println(current.getText());
		
		if (current.getYes() != null) {
			saveNext(output, current.getYes());
			saveNext(output, current.getNo());
		}
	}//end

	public void load(Scanner input){
		if (input == null)
			throw new IllegalArgumentException();
		//my.println("Save the current file here");
		loadNode(input, root);
	}//end
	
	private void loadNode (Scanner input, QuestionNode current){
		String entry;
		if (input.hasNextLine()){
			entry = input.nextLine();
			//my.println("entry: " + entry);
			current.setText(entry.substring(2));
			
			if (entry.charAt(0) == 'Q') {
				current.setYes(new QuestionNode(current, "", null, null));
				loadNode(input, current.getYes());
				current.setNo(new QuestionNode(current, "", null, null));
				loadNode(input, current.getNo());
			}
		}//end if
		
		if (current.getParent() == null){
			root = current;
		}
	}//end

	public int totalGames(){
		return gamesPlayed;
	}//end

	public int gamesWon(){
		return gamesWon;
	}//end

	private void ask(QuestionNode current){
		boolean yesOrNo;
		if(current == null)
			throw new IllegalArgumentException();
		
		if (current.isAnswer())
			my.print("Would your object happen to be " + current.getText() + "?");
		else
			my.print(current.getText());
		
		yesOrNo = my.nextBoolean();
		if (current.isAnswer()){
			if (yesOrNo){
				my.println("I won!");
				gamesWon++;
			}
			else {
				my.println("You beat me!");
				learnAnswer(current);
			}
		}//end if
		else {
			if (yesOrNo){
				ask(current.getYes());
			}
			else {
				ask(current.getNo());
			}
		}
	}//end ask
	
	private void learnAnswer(QuestionNode current){
		String newObject;
		String newQuestion;
		boolean answerForObject;
		QuestionNode newQuestionNode;
		QuestionNode newObjectNode;
		my.print("What is your object? ");
		newObject = my.nextLine();
		my.print("Type a yes/no question to distinguish your item from a " + current.getText() + ": ");
		newQuestion = my.nextLine();
		my.print("And what is the answer for your object? ");
		answerForObject = my.nextBoolean();
		
		newQuestionNode = new QuestionNode(current.getParent(), newQuestion, null, null);
		newObjectNode = new QuestionNode(newQuestionNode, newObject, null, null);
		
		if (answerForObject){
			newQuestionNode.setYes(newObjectNode);
			newQuestionNode.setNo(current);
		}
		else {
			newQuestionNode.setYes(current);
			newQuestionNode.setNo(newObjectNode);
		}
		
      
		if (newQuestionNode.getParent() == null){
			// current is root
			root = newQuestionNode;
		}
		else {
			if (newQuestionNode.getParent().getYes() == current){
				newQuestionNode.getParent().setYes(newQuestionNode);
			}
			else if (newQuestionNode.getParent().getNo() == current){
				newQuestionNode.getParent().setNo(newQuestionNode);
			}
		}
		current.setParent(newQuestionNode);
	}//end learnanswer
}//end class 
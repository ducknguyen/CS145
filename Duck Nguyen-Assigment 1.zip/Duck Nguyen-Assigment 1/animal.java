//@author: Duck Nguyen, CS 145, Fall 2016, Section
//Programming Assignment #1, 09/22/16
//animal.java
//This program showcases the Animal class content

import java.util.*; 

public class animal{

   Random rand = new Random();
   private String name;
   private int x;
   private int y;
   private int s; //max speed
   
   //default constructor
   public animal(){   
      this(0, 0, "Unknown", 4);         
   }//end      
   
   //parameterized constructor
   public animal(int x, int y, String name, int s){
      setAnimal(x, y, name, s);
   }//end 


   //getX()
   public int getX(){
      return x; 
   }//end 
   
   //getY() 
   public int getY(){
      return y;
   }//end 
   
   //get name
   public String getName(){
      return name;
   }//end
   
   
   //setter
   public void setAnimal(int x, int y, String name, int s){
      this.x = x;
      this.y = y;
      this.name = name;
      this.s = s;
   }//end
   
   
   // toString 
   public String toString(){
      return "Player: " + name + ", Cordinate: (" + x + ", " + y + ")";
   }//end
   
   
   //check if they're touching or not
   public boolean touching(animal x){
      //default boolean is false 
      boolean touch = false;
      if (x.x == this.x && x.y == this.y)
         touch = true;
      return touch;
   }//end
   
   
   //randomizing animals' movements
   public void move(){   
      switch (rand(6)+1){
         case 1:
            moveUp(rand(s)); 
         case 2:
            moveDown(rand(s));
         case 3:
            moveLeft(rand(s));
         case 4:
            moveRight(rand(s));
      }//end loop
   }//end
   
   
   //directions
   public void moveUp(int unit){
      y+=unit;
   }
   
   public void moveDown(int unit){
      y-=unit;
   }
   
   public void moveLeft(int unit){
      x-=unit;
   }
   
   public void moveRight(int unit){
      x+=unit;
   }
   //emd dorections
   
   
   // generate a random number
   public int rand(int range){
      Random r = new Random();
      return r.nextInt(range) + 1;
   }//end
   
   
}//end of class
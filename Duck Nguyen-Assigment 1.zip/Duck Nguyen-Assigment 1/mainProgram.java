//@author: Duck Nguyen, CS 145, Fall 2016, Section
//Programming Assignment #1, 09/22/16
//animalRace.java
//This program will simulate 5 animals moving and interact with each other

import java.io.*;

public class mainProgram{

   public static void main(String[]args){
      //roster array for 5 animals
      animal[] roster = new animal[5];
      roster[0] = new animal(0,0,"Cockcroach",1);
      roster[1] = new animal(0,0,"Blobfish", 2);
      roster[2] = new animal(0,0,"Chicken", 3);
      roster[3] = new animal(0,0,"Bob", 4);
      roster[4] = new animal(0,0,"Tapeworm", 5);
      
      //display name and starting location
      System.out.println("STARTING LOCATION:");
      for (int i = 0; i < 5; i++){
         System.out.println(roster[i].toString()); 
      }
      
      //simulating animals' movements
      System.out.println("START");
      
      //loop 25 times
      for (int i = 0; i < 25; i++){
      
         System.out.println((i + 1) + ") ");
         
         //moving the animals
         for (int j = 0; j < 5; j++){
            roster[j].move(); 
            System.out.println(roster[j].toString()); //display current location
         }//end for
         
         
         //touch check and fight simulation
         for (int k = 0; k < 5;  k++){
            for(int z = k + 1; z < 5; z++){
               if (roster[k].touching(roster[z]) == true){
                  System.out.print("FIGHT! FIGHT! ");
                  System.out.println(roster[k].getName() + " V.S. " + roster[z].getName());
               }
            }
         }
         System.out.println("**********************");
         
      }//end of 25 loops
      
      //final location
      System.out.println("FINAL LOCATION: ");
      for (int i = 0; i < 5; i++){
         System.out.println(roster[i].toString()); 
      }//emd
      
   }//end of main
   
}//end of program
             
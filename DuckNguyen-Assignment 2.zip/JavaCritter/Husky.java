//author: Duck Nguyen
//CS145 Assignment 2- 09/30/16
//Husky.java
//This is the program for the Husky Class

import java.awt.*;
import java.util.*; 

public class Husky extends Critter {
   //int count keep track of movement
   private int count;
	
	//constructor
	public Husky() {
		this.count = 0;
   }
	//toString method
	public String toString() {
		this.count = this.count +1;
		if (count % 2 == 1) {
			return "X";
		} 
      else {
		   return "x";
		}
	}//end 
	
   
	//Husky movements/actions
	public Action getMove(CritterInfo info) {
		if (info.getFront() == Neighbor.OTHER) {
			return Action.INFECT;
		} 
      else if(info.getFront() == Neighbor.SAME){
         return Action.RIGHT;
      }
      else if(info.getFront() == Neighbor.WALL){
         return Action.LEFT;
      }
      else {
			return Action.HOP;
		}
	}//end
}//end Husky class
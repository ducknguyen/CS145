//author: Duck Nguyen
//CS145 Assignment 2- 09/30/16
//Giant.java
//This is the program for the Lion Class

import java.awt.*;

public class Giant extends Critter {

	private int count;
   //previous name
	private String xName;
	private final String[] name = {"fee", "fie", "foe", "fum"};
   //giving each giant name a number 
	private int gNum;
	
	//constructor
	public Giant() {
		this.count = 0;
		this.gNum = 0;
	}//end 
	
	//giant's color
	public Color getColor() {
		return Color.GRAY;
	}//end
	
	//toString method
	public String toString() {
		this.count = this.count + 1;
		if ((this.count - 1) % 6 == 0) {
			if (this.gNum == 4) {
				this.gNum = 0;
			}
			this.gNum = this.gNum + 1;
			return name[gNum - 1].toString();
		} 
      else {
			this.xName = name[gNum - 1];
		}
		return this.xName;
	}//end
	
	//giant movements/actions 
	public Action getMove(CritterInfo info) {
		if (info.getFront() == Neighbor.OTHER) {
			return Action.INFECT;
		} 
      else if (info.getFront() != Neighbor.EMPTY) {
			return Action.RIGHT;
		} 
      else {
			return Action.HOP;
		}
	}//end
}//end giant class
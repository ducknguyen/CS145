//author: Duck Nguyen
//CS145 Assignment 2- 09/30/16
//Bear.java
//This is the program for the Bear Class

import java.awt.*;

public class Bear extends Critter {
   //int count keep track of movement
   private int count;
	private boolean polar;
	
	//constructor
	public Bear(boolean polar) {
		this.count = 0;
		this.polar = polar;
	}//end
	
	//returning color of bear
	public Color getColor() {
		if (this.polar) {
			return Color.WHITE;
		} 
      else {
			return Color.BLACK;
		}
	}//end 
	
	//toString method
	public String toString() {
		this.count = this.count +1;
		if (count % 2 == 1) {
			return "/";
		} 
      else {
		   return "\\";
		}
	}//end 
	
   
	//Bear movements/actions
	public Action getMove(CritterInfo info) {
		if (info.getFront() == Neighbor.OTHER) {
			return Action.INFECT;
		} 
      else if (info.getFront() == Neighbor.EMPTY) {
			return Action.HOP;
		}
       
      else {
			return Action.LEFT;
		}
	}//end
}//end Bear class
//author: Duck Nguyen
//CS145 Assignment 2- 09/30/16
//Bear.java
//This is the program for the Lion Class
import java.awt.*;
import java.util.*;


public class Lion extends Critter {
   //random for color
   Random rand = new Random(); 
   private int count;
	private Color col;
	
	//constructor 
	public Lion() {
		this.count = 0;
	}//end
	
	//randomizing color every 3 moves
	public Color getColor() {
		this.count = this.count + 1;
      //using 1 color for 3 moves
		if ((this.count - 1) % 3 == 0){ 
			Color randColor = getColor(rand);
			this.col = randColor;
			return randColor;
		} 
      else {
			return this.col;
		}
	}//end
	
   //choose color (r,g,b)
	public Color getColor(Random rand) {
      int n = rand.nextInt(3) +1; 
      if (n==1){
         return Color.RED;
      }
      else if (n==2){
         return Color.GREEN;
      }
      else{
         return Color.BLUE;
      }     
	}//end 
   
   
	//toString method
	public String toString() {
		return "L";
	}//end
	
   
	//lion's movement/actions
	public Action getMove(CritterInfo info) {
      
      //facing enemy 
		if (info.getFront() == Neighbor.OTHER) {
			return Action.INFECT;
		}
      //facing wall 
      else if (info.getFront() == Neighbor.WALL || info.getRight() == Neighbor.WALL) {
			return Action.LEFT;
		}
      //facing neighbor 
      else if (info.getFront() == Neighbor.SAME) {
			return Action.RIGHT;
		} 
      else {
			return Action.HOP;
		}
	}//end 
}//end Lion Class